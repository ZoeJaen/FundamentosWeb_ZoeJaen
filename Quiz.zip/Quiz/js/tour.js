//variables controladoras  
var panorama, viewer, container, infospot;

//obtener una referencia al contenedor donde se mostrará la escena 3D
container = document.querySelector('#container_principal');

//cargar la foto 360
panorama = new PANOLENS.ImagePanorama('../imagenes/foto.jpg');

// TEXTO 1
var infospot1 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot1.position.set(0, 0, -500);
infospot1.addHoverText('La montaña de Montserrat, situada a unos 50 kilómetros de Barcelona, es uno de los parajes naturales más emblemáticos de Cataluña. Su silueta única, formada por impresionantes agujas de roca, ha inspirado leyendas, artistas y peregrinos durante siglos. En su cima se encuentra el famoso monasterio benedictino de Santa María de Montserrat, hogar de la “Moreneta”, la patrona de Cataluña..', -60);
panorama.add(infospot1);

// TEXTO 2
var infospot2 = new PANOLENS.Infospot(70, PANOLENS.DataImage.Info);
infospot2.position.set(-126 ,5 , 500);
infospot2.addHoverText('Además de su valor espiritual, Montserrat es un destino ideal para los amantes de la naturaleza y el senderismo, con múltiples rutas que ofrecen vistas panorámicas espectaculares. El acceso puede hacerse en coche, tren cremallera o teleférico, lo que convierte la visita en una experiencia inolvidable.', -60);
panorama.add(infospot2);

// VIDEO 1
var infospot3 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot3.position.set(312 ,344 , 500);
infospot3.addHoverText('Conoce las bellezas escenicas y transfondo cultural de este lugar en este video', -60);
panorama.add(infospot3);

// VIDEO 2
var infospot4 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot4.position.set(499 ,-206 , 37);
infospot4.addHoverText('Cómo llegar a Monserrat si te encuentras en Barcelona.', -60);
panorama.add(infospot4);

// AUDIO 1
var infospot5 = new PANOLENS.Infospot(100, PANOLENS.DataImage.Info);
infospot5.position.set(500 ,354 , -222);
infospot5.addHoverText('Audio 1', -60);
panorama.add(infospot5);

// PDF 1
var infospot6 = new PANOLENS.Infospot(90, PANOLENS.DataImage.Info);
infospot6.position.set(500 ,458 , 39);
infospot6.addHoverText('Haz clic para abrir el documento PDF', -60);
panorama.add(infospot6);

// PDF 2
var infospot7 = new PANOLENS.Infospot(80, PANOLENS.DataImage.Info);
infospot7.position.set(-265 ,-99 , -500);
infospot7.addHoverText('Haz clic para abrir el documento PDF', -60);
panorama.add(infospot7);

// IMAGEN 1
var infospot8 = new PANOLENS.Infospot(80, PANOLENS.DataImage.Info);
infospot8.position.set(500 ,98 , 375);
infospot8.addHoverText('Haz clic para ver más', -60);
panorama.add(infospot8);

// IMAGEN 2
var infospot9 = new PANOLENS.Infospot(80, PANOLENS.DataImage.Info);
infospot9.position.set(302 ,123 , -500);
infospot9.addHoverText('Haz clic para ver más', -60);
panorama.add(infospot9);

// SWEET ALERT
var infospot10 = new PANOLENS.Infospot(80, PANOLENS.DataImage.Info);
infospot10.position.set(-500 ,-57 , -404);
infospot10.addHoverText('Haz clic para ver más', -60);
panorama.add(infospot10);

// ---- AGREGA LA PANORÁMICA AL VISOR ----
viewer = new PANOLENS.Viewer({ container: container });
viewer.add(panorama);

// ---- CUANDO LA PANORÁMICA ENTRA EN ESCENA ----
panorama.addEventListener('enter-fade-start', function () {

  // 🔹 Usamos un pequeño retraso para asegurarnos de que Panolens haya creado los .element
  setTimeout(() => {

    // ---- TEXTO 1 ----
    infospot1.element.innerHTML = `
      <div style="background-color: rgba(4, 109, 48, 0.69); color:#fff;
                  border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">
        La montaña de Montserrat, situada a unos 50 kilómetros de Barcelona, es uno de los parajes naturales más emblemáticos de Cataluña.
        Su silueta única, formada por impresionantes agujas de roca, ha inspirado leyendas, artistas y peregrinos durante siglos.
        En su cima se encuentra el famoso monasterio benedictino de Santa María de Montserrat, hogar de la “Moreneta”, la patrona de Cataluña.
      </div>
    `;

    // ---- TEXTO 2 ----
    infospot2.element.innerHTML = `
      <div style="background-color: rgba(26, 128, 68, 0.8); color:#fff;
                  border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">
        Además de su valor espiritual, Montserrat es un destino ideal para los amantes de la naturaleza y el senderismo,
        con múltiples rutas que ofrecen vistas panorámicas espectaculares. El acceso puede hacerse en coche, tren cremallera
        o teleférico, lo que convierte la visita en una experiencia inolvidable.
      </div>
    `;

    // ---- VIDEO 1 ----
    infospot3.element.innerHTML = `
      <div>
        <iframe width="420" height="280"
                src="https://www.youtube.com/embed/z0tUs_W78Mo?si=IcVLitkKFaCNoFzC"
                allowfullscreen></iframe>
      </div>
    `;

    // ---- VIDEO 2 ----
    infospot4.element.innerHTML = `
      <div>
        <iframe width="420" height="280"
                src="https://www.youtube.com/embed/Qv7NxNcmoag?si=4mUA0FFwe4JXpWLb"
                allowfullscreen></iframe>
      </div>
    `;

    // ---- AUDIO  ----
  infospot5.element.innerHTML = `
    <div style="background-color: rgba(156, 212, 226, 0.9); color:#000;
                border-radius: 5px; padding: 10px; font-size: 14px; width: 320px;">
      <p style="margin-bottom: 8px;">Reproduce el audio 1:</p>
      <audio controls>
        <source src="../audio/audio1.mp3" type="audio/mpeg">
      </audio>
    </div>
  `;

    // ---- PDF (infospot6) ----
    infospot6.element.innerHTML = `
      <div style="background-color: rgba(69, 148, 208, 1); color:#fff;
                  border-radius: 5px; padding: 10px; font-size: 14px; width: 220px; text-align: center;">
        <p>Haz clic abajo para abrir el documento</p>
        <a href="https://www.revistaambienta.es/content/dam/revistaambienta/files-1/Revista-Ambienta/AMBIENTA/28/Ambienta_2003_28_a8.pdf" target="_blank"
           style="display:inline-block; background:#fff; color:#000; padding:8px 12px;
                  border-radius:5px; text-decoration:none; font-weight:bold;">
           Ver PDF
        </a>
      </div>
    `;

    // ---- PDF (infospot7) ----
    infospot7.element.innerHTML = `
      <div style="background-color: rgba(69, 148, 208, 1); color:#fff;
                  border-radius: 5px; padding: 10px; font-size: 14px; width: 220px; text-align: center;">
        <p>Haz clic abajo para abrir el documento</p>
        <a href="https://www.turismebaixllobregat.com/sites/default/files/recursnatural/fitxer/opuscle_pnm_cast_uk.pdf" target="_blank"
           style="display:inline-block; background:#fff; color:#000; padding:8px 12px;
                  border-radius:5px; text-decoration:none; font-weight:bold;">
           Ver PDF
        </a>
      </div>
    `;

    // ---- IMAGEN + TEXTO (infospot8) ----
    infospot8.element.innerHTML = `
      <div style="background-color: rgba(0, 0, 0, 0.8); color: #fff;
                  border-radius: 10px; padding: 10px; width: 250px; text-align: center;">
        <img src="imagenes/monserrat1.jfif" alt="Ejemplo"
             style="width: 100%; border-radius: 8px; margin-bottom: 8px;">
        <p style="font-size: 14px;">Después de la edificación de varias ermitas, alrededor del año 1025 se estableció un monasterio que se convirtió en santuario y residencia permanente de la imagen de la Virgen. Este lugar llegó a conocerse como el monasterio de Santa María, actualmente conocido como el Monasterio de Montserrat..</p>
      </div>
    `;

    // ---- IMAGEN + TEXTO (infospot9) ----
    infospot9.element.innerHTML = `
      <div style="background-color: rgba(0, 0, 0, 0.8); color: #fff;
                  border-radius: 10px; padding: 10px; width: 250px; text-align: center;">
        <img src="imagenes/monserrat2.jpg" alt="Ejemplo"
             style="width: 100%; border-radius: 8px; margin-bottom: 8px;">
        <p style="font-size: 14px;">Destacándose sobre la llanura que lo rodea, Montserrat se ha convertido en uno de los símbolos más representativos de Cataluña. Declarado Parque Natural en 1987, alberga una flora y fauna exclusivas de la zona. Gracias a su clima característico y a los contrastes generados por la altitud y la cercanía al mar, en este lugar se formó un ecosistema singular. de la Virgen. Este lugar llegó a conocerse como el monasterio de Santa María, actualmente conocido como el Monasterio de Montserrat..</p>
      </div>
    `;


        // ---- SWEET ALERT (infospot10) ----
    infospot10.addEventListener('click', function () {
      Swal.fire({
        title: '¡Bienvenido al recorrido Virtual Montaña Monserrat!',
        text: 'Conozca mas acerca de este sitio turistico',
        icon: 'success',
        confirmButtonText: 'Cerrar',
        background: 'rgba(255, 255, 255, 0.95)',
        color: '#333',
        confirmButtonColor: '#3085d6',
      });
    });


  }, 500); // 🕒  medio segundo de espera para asegurar el DOM de Panolens
});