const select =  document.getElementById("selectEnlaces");

select.addEventListener("change", () => {
    const url = select.value
    
    if (url) {
        window.open(url,"_blank");
         select.selectedIndex = 0
    }
})