let parqueNacional = document.getElementById('parqueNacional');
let detalle = document.getElementById('detalle');
let resultado = document.getElementById('resultadoR4');

parqueNacional.addEventListener('change', mostrarDetalle);

function mostrarDetalle() {

    let parqueSeleccionado = parqueNacional.value;

    resultadoR4.style.backgroundImage = `url('../imagenes/${parqueSeleccionado}.jpg')`;

    if (parqueSeleccionado == "") {
        detalle.innerHTML = "";
    }
    if (parqueSeleccionado == 1) {
        detalle.innerHTML = 'Un parque pequeño pero espectacular, ideal para quienes quieren combinar playas de arena blanca con senderos en selva tropical. Perfecto para ver monos, iguanas y aves, y disfrutar de atardeceres junto al mar.';
    } else if (parqueSeleccionado == 2) {
        detalle.innerHTML = 'El imponente volcán Arenal domina el paisaje. El parque ofrece caminatas por senderos, vistas panorámicas del lago Arenal y la oportunidad de relajarse en aguas termales naturales. Ideal para amantes de la naturaleza y la aventura.';
    } else if (parqueSeleccionado == 3) {
        detalle.innerHTML = 'Un paraíso para los amantes de la vida salvaje, con selva virgen y biodiversidad increíble. Aquí puedes ver jaguares, tapires, monos y aves exóticas en su entorno natural. Perfecto para los que buscan experiencias auténticas de ecoturismo.';
    } else if (parqueSeleccionado == 4) {
        detalle.innerHTML = 'Famoso por sus canales y ríos tranquilos, es el lugar principal donde las tortugas verdes y carey anidan cada año. También es hogar de aves, monos y caimanes. Una experiencia única de naturaleza y conservación.';
    } else if (parqueSeleccionado == 5) {
        detalle.innerHTML = 'Un parque lleno de volcanes activos, cataratas y géiseres. Sus senderos permiten explorar la naturaleza y disfrutar de aguas termales y paisajes volcánicos. Ideal para quienes buscan aventura y paisajes únicos.';
    }

}


