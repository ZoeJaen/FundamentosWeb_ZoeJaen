let contFactura = 1

function Facturar () {
    //DOM

let nombreDesp = document.getElementById("nombre").value
let articuloDesp = document.getElementById("articulo").value
let cantidadDesp =  Number(document.getElementById("cantidad").value)
let precioUnit =  Number(document.getElementById("precio").value)

    //CALCULO

subtotal = precioUnit * cantidadDesp
iva = subtotal * 0.13
servicio = subtotal * 0.05
total = subtotal + iva + servicio

    // LLENAR OTROS DATOS: fecha, facturaNo

const fechaActual = new Date ()
const fechaFormateada = fechaActual.toLocaleString(); 
fecha.value = fechaFormateada

// DEVOLVER

document.getElementById("numFactura").value = contFactura
document.getElementById("fecha").value = fechaFormateada
document.getElementById("nombreDesp").value = nombreDesp
document.getElementById("articuloDesp").value = articuloDesp
document.getElementById("cantidadDesp").value = cantidadDesp.toFixed(2)
document.getElementById("subtotal").value = subtotal.toFixed(2)
document.getElementById("iva").value = iva.toFixed(2)
document.getElementById("servicio").value = servicio.toFixed(2)
document.getElementById("total").value = total.toFixed(2)

contFactura++;

}