window.onload=function () {

    document.getElementById("color").onchange = function (opcion){
        color = opcion.target.value; 

        if( color== "Azul"){
            imagen = "../imagenes/azul.jpg"
        } else if (color == "Rojo"){
            imagen = "../imagenes/rojo.jpg"
        } else if (color == "Negro") {
            imagen = "../imagenes/negro.jpg"
        } else if (color == "Gris") {
            imagen = "../imagenes/gris.jpg"
        } else if (color == "Blanco") {
            imagen = "../imagenes/blanco.jpg"
        }

        document.getElementById("imagen").src= imagen;
    }
}