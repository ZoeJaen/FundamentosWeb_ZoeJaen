function convertirColonesADolares() {
    let colones = 0
    let cambio = 0 //valor de un dolar en colones, dado por el usuario
    let resultadoaDolares = 0

//DOM
    colones = Number(document.getElementById("colones").value)
    cambio = Number(document.getElementById("cambiof1").value)

//CALCULO
    resultadoaDolares = colones / cambio;

// RESULTADO     
    document.getElementById("resultadoaDolares").textContent = resultadoaDolares
}

function convertirDolaresAColones() {
    let dolares = 0
    let cambio = 0 //valor de un dolar en colones, dado por el usuario
    let resultadoaColones = 0

//DOM
    dolares = Number(document.getElementById("dolares").value)
    cambio = Number(document.getElementById("cambiof2").value)

//CALCULO
    resultadoaColones = dolares * cambio;

// RESULTADO     
    document.getElementById("resultadoaColones").textContent = resultadoaColones

}

