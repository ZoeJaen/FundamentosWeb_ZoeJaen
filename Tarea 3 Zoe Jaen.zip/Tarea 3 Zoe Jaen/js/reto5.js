let opcionBebida = "";
let opcionTamano = "";
let imagen = ""; 

window.onload=function () {

    document.getElementById("bebida").onchange = function (opcion){
        opcionBebida = opcion.target.value; 

        opcionBebida = opcion.target.value
        if( opcionBebida == "Cafe negro"){
            imagen = "../imagenes/cafe.jpg"
        } else if (opcionBebida == "Cafe capuchino"){
            imagen = "../imagenes/capuchino.jpg"
        } else if (opcionBebida == "Chocolate") {
            imagen = "../imagenes/chocolate.jpg"
        } else if (opcionBebida == "Batido de frutas") {
            imagen = "../imagenes/batido.jpg"
        } else if (opcionBebida == "Gaseosa") {
            imagen = "../imagenes/gaseosa.jpg"
        }

        document.getElementById("imagen").src= imagen;
    }
}

document.getElementById("tamano").onchange = function (opcion){
    opcionTamano = opcion.target.value
}

function calcular () { 
    let bebida = document.getElementById("bebida").value;
    let tamano = document.getElementById("tamano").value;
    //validacion
    if (bebida == "") {
        Swal.fire({
            icon:"info",
            title:"Atencion",
            text:"Seleccionar la bebida y el tamaño"
        }); 
        return;
    }
        if (tamano == ""){
        Swal.fire({
            icon:"info",
            title:"Atencion",
            text:"Seleccionar la bebida y el tamaño"
        }); 
        return;
    }

    let montoPago = 0
        switch (bebida) {
            case "Cafe negro":
            case "Cafe capuchino":
            case "Chocolate" :
            case "Batido de frutas" :
            case "Gaseosa" :
                if (tamano == "Pequeño") {
                    montoPago = 750;
                } else if (tamano == "Mediano") {
                    montoPago = 1150;
                } else {
                    montoPago = 1600;
                    } break;
            default:
            break;
        }
    
    let imagenRuta = "../imagenes/"+ opcionBebida.toLowerCase().split(" ")[0]+ ".jpg";    


    Swal.fire ({
        imageUrl: imagenRuta,
        html: 
        "<p> Bebida y tamaño seleccionado: " +
        opcionBebida + " " + opcionTamano + "<br><br> <strong> Monto a pagar:  </strong></p>" + 
        "₡" + montoPago +  "</p>",
        imageWidth: 300,
        imageHeight: 250,
        imageAlt: "opcion Bebida",
    });
}


