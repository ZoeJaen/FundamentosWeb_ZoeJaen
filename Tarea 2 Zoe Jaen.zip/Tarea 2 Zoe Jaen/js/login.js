document.getElementById("btn-login").addEventListener("click", login); 

function validation_alert(ptext) {
    swal.fire({
        title: "Por favor verificar los datos ingresados",
        text: ptext,
        confirmButtonText: "Intentar de nuevo",
        confirmButtonColor: "#630a48ff",
        html: '<iframe width="320" height="240" frameborder="0" src="https://lottie.host/embed/e5905810-6e25-4c23-8997-00da69d66d4b/5AekzxT9Qu.lottie"></iframe> <br><p>' + ptext + " </p>", 
        customClass:{
            title:"swal-title"
        }
    });
}
function login() {
    let user_input = document.getElementById("in-txt-user").value;
    let pass_input = document.getElementById("in-txt-pass").value;
    
    let username = "cenfo";
    let password = "123";

    let input = [user_input, pass_input]; 

    let input_id = ["in-txt-user", "in-txt-pass"];

    let error_count = 0; 

    let text = "";

    for (let i = 0; i < input.length; i++) {
        document.getElementById(input_id[i]).classList.remove("error"); 
        if (input[i] == "") { 
            text = "Por favor completar los datos de inicio";
            validation_alert(text);
            document.getElementById(input_id[i]).classList.add("error"); 
            error_count++;
        }
    }

    if (error_count == 0) {  
        if (user_input == username && pass_input == password) {
            Swal.fire({
                title: "Éxito: Ingresando",
                showConfirmButton: false,
                customClass: {                 
                    title: 'formatos1',                      
                },
                timer: 3000,
                html: '<iframe width="320" height="240" frameborder="0" src="https://lottie.host/embed/d627d951-cf58-4106-b5df-91557f0ba09c/c3SNbugSCB.lottie"></iframe> <br><br><p>Esperar un momento...</p>',                
            }).then(() => {
                window.location.href = "landing.html"
            });

        } else {
            text = "Usuario o contraseña incorrecta, por favor intenta de nuevo."; 
            validation_alert(text);
        }
    }
}

/* funcion que permite limpiar los campos del FORM HTML */ 
function limpiar(){
    document.getElementById('in-txt-user').value = "";
    document.getElementById('in-txt-pass').value = "";
}
